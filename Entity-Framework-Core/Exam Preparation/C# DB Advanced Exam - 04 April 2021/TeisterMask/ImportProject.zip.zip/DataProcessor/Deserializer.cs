﻿namespace TeisterMask.DataProcessor
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Globalization;
    using System.Text;
    using Data;
    using TeisterMask.Data.Models;
    using TeisterMask.Data.Models.Enums;
    using TeisterMask.DataProcessor.ImportDto;
    using ValidationContext = System.ComponentModel.DataAnnotations.ValidationContext;

    public class Deserializer
    {
        private const string ErrorMessage = "Invalid data!";

        private const string SuccessfullyImportedProject
            = "Successfully imported project - {0} with {1} tasks.";

        private const string SuccessfullyImportedEmployee
            = "Successfully imported employee - {0} with {1} tasks.";

        public static string ImportProjects(TeisterMaskContext context, string xmlString)
        {
            var serialize  =  XmlConverter.Deserializer<ImportProjectDto>(xmlString, "Projects");
            ;
            var sb = new StringBuilder();
            var projects =  new List<Project>();

            foreach (var currProject in serialize)
            {
                if (!IsValid(currProject))
                {
                    sb.AppendLine(ErrorMessage);
                    continue;
                }

                DateTime ProjectOpenDate;

                var parsedOpenDate = DateTime.TryParseExact(currProject.OpenDate,
                    "dd/MM/yyyy",
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out ProjectOpenDate);

                DateTime ProjectDueDate;

                var parsedDueDate = DateTime.TryParseExact(currProject.DueDate,
                    "dd/MM/yyyy",
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out ProjectDueDate);

                var project =  new Project
                {
                    Name = currProject.Name,
                    OpenDate =ProjectOpenDate,
                    DueDate = parsedDueDate ? (DateTime?) ProjectDueDate : null
                };


                foreach (var currTask in currProject.Tasks)
                {
                    if (currTask.Name == "")
                    {
                        Console.WriteLine();
                    }
                    if (!IsValid(currTask))
                    {
                        sb.AppendLine(ErrorMessage);
                        continue;
                    }

                    // First Step
                    DateTime TaskOpenDate;

                    var parsedTaskOpenDate = DateTime.TryParseExact(currTask.OpenDate,
                    "dd/MM/yyyy",
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out TaskOpenDate);

                    if (!parsedTaskOpenDate)
                    {
                        sb.AppendLine(ErrorMessage);
                        continue;
                    }

                    if (TaskOpenDate < ProjectOpenDate)
                    {
                        sb.AppendLine(ErrorMessage);
                        continue;
                    }

                    DateTime TaskDueDate;

                    var parsedTaskDueDate = DateTime.TryParseExact(currTask.DueDate,
                    "dd/MM/yyyy",
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out TaskDueDate);

                    if (!parsedTaskOpenDate)
                    {
                        sb.AppendLine(ErrorMessage);
                        continue;
                    }

                    if (project.DueDate.HasValue)
                    {
                        if (TaskDueDate > ProjectDueDate)
                        {
                            sb.AppendLine(ErrorMessage);
                            continue;
                        }
                    }


                    //Enum executionType;
                    //Enum labelType;

                    //var isExecutionTypeValid = Enum.TryParse(currTask.ExecutionType, out executionType);
                    //var isLabelTypeValid = Enum.TryParse(currTask.LabelType, out labelType);

                    var task =  new Task
                    {
                        Name = currTask.Name,
                        OpenDate = TaskOpenDate,
                        DueDate = TaskDueDate,
                        LabelType = (LabelType)currTask.LabelType,
                        ExecutionType = (ExecutionType)currTask.ExecutionType
                    };

                    project.Tasks.Add(task);
                }

                sb.AppendLine($"Successfully imported project - {project.Name} with {project.Tasks.Count} tasks.");

                projects.Add(project);
            }

            context.Projects.AddRange(projects);
            context.SaveChanges();

            //	If there are any validation errors for the task entity(such as invalid name, open or due date are missing,
            //	task open date is before project open date or task due date is after project due date),
            //	do not import it(only the task itself, not the whole project) and append an error message to the method output.

            return sb.ToString().TrimEnd();
        }

        public static string ImportEmployees(TeisterMaskContext context, string jsonString)
        {
            throw new NotImplementedException();
        }

        private static bool IsValid(object dto)
        {
            var validationContext = new ValidationContext(dto);
            var validationResult = new List<ValidationResult>();

            return Validator.TryValidateObject(dto, validationContext, validationResult, true);
        }

        public static int CompareDates(DateTime dateOne, DateTime dateTwo)
        {
            return DateTime.Compare(dateOne, dateTwo);
        }
    }
}