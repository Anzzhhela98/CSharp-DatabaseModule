﻿namespace SoftJail.DataProcessor
{
    using Data;
    using Newtonsoft.Json;
    using System;
    using System.Linq;

    public class Serializer
    {
        public static string ExportPrisonersByCells(SoftJailDbContext context, int[] ids)
        {
            var prisoners = context
                .Prisoners
                .ToList()
                .Where(p => ids.Contains(p.Id))
                .Select(p => new
                {
                    Id = p.Id,
                    Name = p.FullName,
                    CellNumber = p.Cell.CellNumber,
                    Officers = p.PrisonerOfficers.Select(po => new
                    {
                        OfficerName = po.Officer.FullName,
                        Department = po.Officer.Department.Name
                    })
                        .OrderBy(o => o.OfficerName)
                        .ToList(),
                    TotalOfficerSalary = decimal.Parse( p.PrisonerOfficers
                         .Sum(po => po.Officer.Salary)
                         .ToString("F2"))
                })
                .OrderBy(p => p.Name)
                .ThenBy(p => p.Id)
                .ToList();



            var json = JsonConvert.SerializeObject(prisoners, Formatting.Indented);

            return json;
        }

        //Export all prisoners that were processed which have these ids.
        //For each prisoner, get their id, name, cell number they are placed in, their officers with each officer name,
        //     and the department name they are responsible for.
        // At the end export the total officer salary with exactly two digits after the decimal place. 
        //Sort the officers by their name (ascending), sort the prisoners by their name (ascending), then by the prisoner id (ascending).


        public static string ExportPrisonersInbox(SoftJailDbContext context, string prisonersNames)
        {
            throw new NotImplementedException();
        }
    }
}